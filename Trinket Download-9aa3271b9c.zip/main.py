#This program was created to determine the smallest number out of a number of variables.
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
num3 = int(input("Enter the third number: "))
#These are the if statements controlling this equalled numbers.
if num1 == num2 < num3:
  print(num1, "is the smallest number.")
elif num1 == num3 < num2:
  print(num1, "is the smallest number.")
elif num1 == num3 < num2:
  print(num1, "is the smallest number.")
elif num2 == num1 < num3:
  print(num1, "is the smallest number.")
elif num2 == num3 < num1:
  print(num2, "is the smallest number.")
elif num3 == num1 < num2:
  print(num3, "is the smallest number")
elif num3 == num2 < num1:
  print(num1, "is the smallest number.")
elif num1 == num2 == num3:
  print("All the numbers are equal")
#These are the if statements cotrolling the different variables.
elif (num1 < num2)and (num1 < num3):
  print(num1, "is the smallest number.")
elif (num2 < num1) and (num2 < num3):
  print(num2, "is the smallest number.")
elif (num3 < num1) and (num3 <  num2):
  print(num3, "is the smallest number.")
